# Mean-assignment
Assignment for MEAN Stack Development
